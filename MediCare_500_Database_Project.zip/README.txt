MEDICARE NLP PROJECT – 500 MEDICINE CATALOGUE
================================================

WHAT IS INCLUDED
- Flask login and registration
- User age saved in SQLite
- Medicine search using text normalization and fuzzy matching
- CSV-to-SQLite importer for 500 Indian medicine catalogue records
- Search by product/brand name or composition
- Medicine catalogue metadata: composition, manufacturer, price and pack size

IMPORTANT DATA LIMITATION
The public Indian Medicine Dataset used by this project supplies catalogue metadata:
product name, price, manufacturer, type, pack size and composition.
It does NOT supply clinically verified uses, side effects, age-specific precautions
or dosage instructions. The importer therefore does not invent these details.
Those fields are clearly labelled as unavailable and must be checked against
authoritative product leaflets by a qualified healthcare professional.

The website is an educational student project, not a medical device.
It must not be used to diagnose, prescribe, or calculate a personal dose.
Age alone is not enough to determine a safe dose.

SETUP ON WINDOWS
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. Create virtual environment:
      py -m venv venv
5. Activate:
      venv\Scripts\activate
6. Install Flask:
      pip install -r requirements.txt
7. Import 500 medicine catalogue records:
      python import_medicines.py
   This step requires an internet connection.
8. Start website:
      python app.py
9. Open:
      http://127.0.0.1:5000

IMPORTANT
Run import_medicines.py before app.py. It downloads the public CSV, creates
medicines.csv, and imports the first 500 unique product records into medicare.db.

If you already have an old medicare.db:
- Your existing users are preserved.
- The importer replaces only the medicines table records.
- Back up your database before importing if you need to preserve old medicine data.

DATA SOURCE
Indian Medicine Dataset:
https://github.com/junioralive/Indian-Medicine-Dataset
The source repository describes product name, price, manufacturer, type,
pack size and composition fields. Review its license and terms before
redistributing the dataset.
